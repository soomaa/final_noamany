# ملفات تسليم تطبيق Noamany لمهندس Flutter

ابدأ باستيراد الملف `NOAMANY_FLUTTER_COMPLETE.postman_collection.json` في Postman. الملف يجمع في Collection واحدة:

- كل endpoints التطبيق القديم تحت `/Api/*` بنفس الأسماء المستخدمة في التطبيق الحالي.
- كل REST API الحديث تحت `/api/mobile/*`.
- رفع صور البصمة والأنشطة ومرفقات الرسائل والمستندات.
- الحضور والانصراف وكل الإجراءات والتقارير والإعدادات التابعة له.
- الإجازات والأذونات والمهام والتعاميم والإنذارات واللوائح.
- الأنشطة والرسائل الداخلية والسلف ودورة الموافقات.

## الإعداد

غيّر Collection variable باسم `baseUrl` إلى رابط الخادم بدون `/api`، ثم نفّذ `login_app` للتطبيق القديم أو `Login` داخل مجلد Modern Mobile. اختبار تسجيل الدخول يحفظ `accessToken` تلقائياً لباقي الطلبات.

لا ترسل `emp_id` لتحديد الموظف في العمليات المحمية؛ الخادم يأخذ هوية الموظف من JWT. القيم مثل `taskId`, `loanId`, `messageId` و`shiftId` هي Collection variables يضع فيها مهندس Flutter الرقم الراجع من عملية الإضافة أو القائمة.

## الملفات

- `NOAMANY_FLUTTER_COMPLETE.postman_collection.json`: ملف Postman الشامل وهو الملف الأساسي.
- `noamany_legacy_api.dart`: ثوابت أسماء endpoints القديمة الجاهزة للاستخدام داخل Flutter.
- `FLUTTER_LEGACY_API_HANDOFF.md`: توثيق الحقول والاستجابات للتطبيق القديم.
- `FLUTTER_ATTENDANCE_API.md`: منطق الحضور والانصراف والموقع والصورة والأخطاء.
- `FLUTTER_CONTENT_AND_LOANS_API.md`: اللوائح والأنشطة والرسائل الداخلية والسلف.
- `MOBILE_API_INTEGRATION_TEST_REPORT.md`: تقرير الاختبار الفعلي، 112 سيناريو ناجح من 112.

الموصى به للتطبيق القائم هو الاستمرار على `/Api/*` لتقليل تعديلات Flutter. يمكن استخدام `/api/mobile/*` للشاشات الجديدة أو عند إعادة تنظيم networking layer.
